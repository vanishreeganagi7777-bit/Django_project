from django.db import models

# Create your models here.
#ORM=>Object Relational Mapping 

class Drink(models.Model):
    name=models.CharField(max_length=100)
    price=models.FloatField(max_length=20)
    desc=models.TextField()

    def __str__(self):
        return self.name