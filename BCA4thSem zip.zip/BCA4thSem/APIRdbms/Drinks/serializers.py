from rest_framework import serializers
from .models import Drink

class DrinkSerializer(serializers.ModelSerializer):
    class Meta:   ##This stores the information about models
        model=Drink
        fields='__all__'  ##all means serialize all the fields like name, description, quantity
        