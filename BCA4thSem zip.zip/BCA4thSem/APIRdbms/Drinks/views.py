from django.shortcuts import render
from django.http import HttpResponse
from .models import Drink
from .serializers import DrinkSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
# Create your views here.
#there are two:
#function based view
#class based view

#make a folder like templates and make another folder and name that as the file name like templates/appname/filename.html
def home(request):
    return render(request, 'Drinks/index.html', context={})

##implementation of rest api: 
##Note: The rest api is helping to do CRUD operations by the client (GET, POST, DELETE, PUT)

## from frontend JSON will come and then get converted into python and then that python code will
#  be converted into sql through ORM(Object Relationsla Mapping) This process is called is called Serialization.
##The vice-versa is called Deserialiation.



##First GET 
@api_view(['GET'])
def get_drinks(request):
    if request.method == 'GET':
        drinks = Drink.objects.all() # [obj1,obj2,obj3]
        drinkserializer = DrinkSerializer(drinks,many=True) # [obj1,obj2,obj3] -> [{name: ,price: ,des: ,q:},{},{}]
        return  Response(drinkserializer.data)
    
#get specific drink
@api_view(['GET'])
def get_specific_drink(request, id):
    if request.method == 'GET': #
        drink = Drink.objects.get(id=id) # all abojects[]
        drinkserilizer= DrinkSerializer(drink) 
        return Response(drinkserilizer.data)

# put method Update the drink
@api_view(['PUT'])
def put_drink(request, id):
    if request.method == 'PUT':
        datac = request.data
        datadb = Drink.objects.get(id=id) # all abojects[]
        drinkserializer= DrinkSerializer(datadb, datac) 
        print("hiiiiii")
        if drinkserializer.is_valid():
            drinkserializer.save()
            return Response(drinkserializer.data, status=200)
        return Response(drinkserializer.errors, status=400)

# post method
@api_view(['POST'])
def create_drink(request):
    if request.method == 'POST':
        data = request.data
        drinkserializer = DrinkSerializer(data=data)
        if drinkserializer.is_valid():
            drinkserializer.save()
            return Response(drinkserializer.data, status=201)
        return Response(drinkserializer.errors, status=400)
    
@api_view(['DELETE'])    
def delete_drink(request, id):
    if request.method=='DELETE':
        drink=Drink.objects.get(id=id)
        drink.delete()
        return Response(status=204)